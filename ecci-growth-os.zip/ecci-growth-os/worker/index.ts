// Worker entrypoint for ECCI Growth OS.
//
// This project was originally authored for Cloudflare Pages (file-based routing
// under functions/api/*). The Cloudflare project this repo deploys to runs
// `npx wrangler deploy` (Workers), which does not understand the functions/
// directory or `pages_build_output_dir`. This file re-uses the exact same
// handler functions and manually maps each API route, then falls back to the
// static assets binding (built by `vite build` into dist/) for everything else.
//
// If you add a new file under functions/api/, add a matching import + route
// entry below.

import { onRequestGet as health } from "../functions/api/health";
import { onRequestPost as generateVisualCreative } from "../functions/api/generate-visual-creative";
import { onRequestPost as scanWebsite } from "../functions/api/scan-website";
import { onRequestPost as cloudflareDeployTrigger } from "../functions/api/cloudflare/deploy-trigger";
import { onRequestGet as cloudflareConfig } from "../functions/api/cloudflare/config";
import { onRequestPost as generateVideoScript } from "../functions/api/generate-video-script";
import { onRequestPost as generateIntelligence } from "../functions/api/generate-intelligence";
import { onRequestPost as paypalCapture } from "../functions/api/billing/paypal/capture";
import { onRequestPost as paypalCreateSubscription } from "../functions/api/billing/paypal/create-subscription";
import { onRequestPost as paytmInitiate } from "../functions/api/billing/paytm/initiate";
import { onRequestPost as paytmCallback } from "../functions/api/billing/paytm/callback";
import { onRequestPost as generateReport } from "../functions/api/generate-report";
import { onRequestPost as generateTextCreative } from "../functions/api/generate-text-creative";
import { onRequestGet as agencyResolveTheme } from "../functions/api/agency/resolve-theme";
import { onRequestPost as agencyBrandingUpdate } from "../functions/api/agency/branding/update";
import { onRequestPost as agencyDomainVerify } from "../functions/api/agency/domain/verify";
import { onRequestPost as optimizeBudget } from "../functions/api/optimize-budget";

type EventContext = { request: Request; env: Record<string, any> };
type Handler = (context: EventContext) => Promise<Response>;

const routes: Record<string, Partial<Record<string, Handler>>> = {
  "/api/health": { GET: health },
  "/api/generate-visual-creative": { POST: generateVisualCreative },
  "/api/scan-website": { POST: scanWebsite },
  "/api/cloudflare/deploy-trigger": { POST: cloudflareDeployTrigger },
  "/api/cloudflare/config": { GET: cloudflareConfig },
  "/api/generate-video-script": { POST: generateVideoScript },
  "/api/generate-intelligence": { POST: generateIntelligence },
  "/api/billing/paypal/capture": { POST: paypalCapture },
  "/api/billing/paypal/create-subscription": { POST: paypalCreateSubscription },
  "/api/billing/paytm/initiate": { POST: paytmInitiate },
  "/api/billing/paytm/callback": { POST: paytmCallback },
  "/api/generate-report": { POST: generateReport },
  "/api/generate-text-creative": { POST: generateTextCreative },
  "/api/agency/resolve-theme": { GET: agencyResolveTheme },
  "/api/agency/branding/update": { POST: agencyBrandingUpdate },
  "/api/agency/domain/verify": { POST: agencyDomainVerify },
  "/api/optimize-budget": { POST: optimizeBudget },
};

export default {
  async fetch(request: Request, env: Record<string, any>): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    if (path.startsWith("/api/")) {
      const route = routes[path];
      if (!route) {
        return Response.json({ error: "Not found" }, { status: 404 });
      }
      const handler = route[request.method];
      if (!handler) {
        return Response.json({ error: "Method not allowed" }, { status: 405 });
      }
      try {
        return await handler({ request, env });
      } catch (err: any) {
        console.error(`Error handling ${path}:`, err);
        return Response.json({ error: err?.message || "Internal error" }, { status: 500 });
      }
    }

    // Not an API route: serve the built SPA assets (dist/). `not_found_handling
    // = "single-page-application"` in wrangler.toml makes unmatched paths (e.g.
    // client-side routes like /dashboard) fall back to index.html.
    return env.ASSETS.fetch(request);
  },
};
