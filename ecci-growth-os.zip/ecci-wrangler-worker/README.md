# ECCI Growth OS — Cloudflare Workers Edition

A React + TypeScript (Vite) single-page app, backed by a single Cloudflare
**Worker** (`worker/index.ts`) written in pure Wrangler module syntax
(`export default { fetch(request, env, ctx) { ... } }`).

This replaces the previous Cloudflare **Pages Functions** convention
(`functions/api/**/onRequestGet|onRequestPost`) and the Next.js/OpenNext
scaffolding with a single deployable Worker + static assets bundle.

## Project layout

```
src/                # React/Vite frontend (unchanged UI)
worker/
  index.ts          # Worker entry point — export default { fetch }
  types.ts           # Env bindings + shared RouteHandler type + Gemini helper
  routes/            # One file per API route, mirrors the old /api/* paths
wrangler.jsonc       # Wrangler config (JSONC) — main = worker/index.ts
wrangler.toml        # Wrangler config (TOML)  — same settings, TOML syntax
```

## Run locally

**Prerequisites:** Node.js 20+, and the [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/) (installed as a dev dependency).

```bash
npm install
cp .dev.vars.example .dev.vars   # add your GEMINI_API_KEY, etc.
npm run build                    # vite build -> dist/
npm run dev                      # wrangler dev (serves Worker + dist/ together)
```

`wrangler dev` runs the actual Worker code locally (not a separate Express
server), so what you test locally is exactly what deploys.

## Deploy

```bash
npx wrangler login
npm run deploy      # vite build && wrangler deploy
```

Before deploying to production, replace the `<YOUR_*_ID>` placeholders in
`wrangler.jsonc` / `wrangler.toml` with real resource IDs (D1, KV, R2,
Hyperdrive) — see `CLOUDFLARE_CONFIG.md` for the full provisioning checklist —
and set secrets with `wrangler secret put <NAME>`.

## API routes

All routes live under `worker/routes/` and are registered in the route table
at the top of `worker/index.ts`. Paths are unchanged from the original app,
so nothing in `src/` needed to change:

| Method | Path |
| --- | --- |
| GET | `/api/health` |
| POST | `/api/scan-website` |
| POST | `/api/generate-visual-creative` |
| POST | `/api/generate-video-script` |
| POST | `/api/generate-intelligence` |
| POST | `/api/generate-text-creative` |
| POST | `/api/generate-report` |
| POST | `/api/optimize-budget` |
| GET | `/api/cloudflare/config` |
| POST | `/api/cloudflare/deploy-trigger` |
| POST | `/api/billing/paypal/capture` |
| POST | `/api/billing/paypal/create-subscription` |
| POST | `/api/billing/paytm/initiate` |
| POST | `/api/billing/paytm/callback` |
| GET | `/api/agency/resolve-theme` |
| POST | `/api/agency/branding/update` |
| POST | `/api/agency/domain/verify` |
