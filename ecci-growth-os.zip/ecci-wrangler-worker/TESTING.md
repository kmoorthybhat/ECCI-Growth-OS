# ECCI Growth OS — Testing & Local Development Guide

This guide details how to configure local environment secrets and execute
testing for ECCI Growth OS: a Vite/React frontend backed by a single
Cloudflare **Worker** (`worker/index.ts`), deployed and run entirely through
Wrangler — no Express server, no Pages Functions.

---

## 1. Local Secrets Setup

Wrangler loads environment variables and secrets locally from `.dev.vars`.

1. Copy the template secrets file to create your local `.dev.vars`:
   ```bash
   cp .dev.vars.example .dev.vars
   ```

2. Open `.dev.vars` and insert your actual API keys:
   ```env
   GEMINI_API_KEY="your_actual_gemini_api_key"
   PAYTM_MID="ECCI_PAYTM_MID_PROD"
   ```

---

## 2. Local Development

Build the frontend once, then run the Worker with `wrangler dev`, which
serves the built SPA (`dist/`) *and* executes `worker/index.ts` for every
`/api/*` request — the same code path that runs in production.

```bash
npm install
npm run build     # vite build -> dist/
npm run dev        # wrangler dev, reads .dev.vars automatically
```

The app will be available at the local URL Wrangler prints (typically
`http://localhost:8787`).

If you're iterating on frontend-only changes, you can also run `vite dev`
directly for fast HMR, but API calls (`/api/*`) will 404 unless `wrangler dev`
is also running — use `wrangler dev` as the source of truth for full-stack
testing.

---

## 3. API Endpoints Testing Checklist

| Path | Method | Payload / Example Request | Expected Response |
| :--- | :--- | :--- | :--- |
| `/api/health` | `GET` | None | `{ "status": "ok", "service": "ECCI Growth OS v1.0 API Engine" }` |
| `/api/scan-website` | `POST` | `{ "websiteUrl": "https://energizecafe.com" }` | Structured `brand_kit` object |
| `/api/generate-intelligence` | `POST` | `{ "brand_kit": { ... } }` | Persona array and `bi_engine` |
| `/api/generate-text-creative` | `POST` | `{ "personaName": "Founder Alex", "adAngle": "Focus" }` | Direct response headlines, primary texts & landing copy |
| `/api/generate-visual-creative` | `POST` | `{ "title": "Matcha Pass", "primaryColor": "#FF4D00" }` | Visual aspect ratio URLs & compliance scores |
| `/api/generate-video-script` | `POST` | `{ "adAngle": "Bio-Optimized Nitro", "personaName": "Alex" }` | TikTok/Reels storyboard, voiceover & script |
| `/api/optimize-budget` | `POST` | `{ "campaigns": [{ "id": "c1", "dailyBudget": 100, "ctr": 3.4, "cpl": 12 }] }` | Budget adjustment suggestions |
| `/api/generate-report` | `POST` | `{ "clientName": "Energize Cult Cafe", "spend": 1800, "leads": 86 }` | Executive performance summary report |
| `/api/cloudflare/config` | `GET` | None | Deployment/config metadata |
| `/api/cloudflare/deploy-trigger` | `POST` | None | Simulated deployment status & logs |
| `/api/billing/paypal/create-subscription` | `POST` | `{ "clientId": "c123", "tier": "Growth", "paymentType": "monthly" }` | Approval URL & subscription order details |
| `/api/billing/paypal/capture` | `POST` | `{ "clientId": "c123", "tier": "Growth" }` | Completed transaction object |
| `/api/billing/paytm/initiate` | `POST` | `{ "clientId": "c123", "amount": 1999 }` | Paytm checksum params & payment link |
| `/api/billing/paytm/callback` | `POST` | `{ "ORDER_ID": "PAYTM_ORD_123", "STATUS": "TXN_SUCCESS" }` | Verified transaction object |
| `/api/agency/domain/verify` | `POST` | `{ "agencyId": "a1", "customDomain": "client.agency.com" }` | Verified CNAME & TXT DNS challenge status |
| `/api/agency/branding/update` | `POST` | `{ "agencyId": "a1", "branding": { "primaryColor": "#7C3AED" } }` | Updated branding confirmation & cache purge |
| `/api/agency/resolve-theme` | `GET` | `?host=client.agency.com` | Resolved tenant white-label branding |

Quick manual smoke test once `wrangler dev` is running:

```bash
curl http://localhost:8787/api/health
curl -X POST http://localhost:8787/api/optimize-budget \
  -H "Content-Type: application/json" \
  -d '{"campaigns":[{"id":"c1","dailyBudget":100,"ctr":3.4,"cpl":12}]}'
```

---

## 4. Build & Production Verification

Before committing changes, run:
```bash
# Typecheck (includes worker/**)
npm run lint

# Production build
npm run build
```

Verify that:
- `dist/index.html` exists (the Vite SPA build), and
- `worker/index.ts` compiles cleanly and imports every file under
  `worker/routes/**` without errors — this is the single Worker deployed by
  `wrangler deploy`, replacing the old per-file Pages Functions.

To fully validate the deployable artifact end-to-end, run `wrangler deploy --dry-run` (bundles the Worker and prints the resulting size/routes without publishing).
