// ==============================================================================
// ECCI Growth OS — Cloudflare Worker (module syntax)
// ==============================================================================
// This is the single Worker entry point. It replaces the old Cloudflare Pages
// Functions convention (functions/api/**/onRequestGet|onRequestPost) with a
// standard `export default { fetch }` module Worker, deployed via
// `wrangler deploy`. All /api/* traffic is routed here; every other request
// falls through to the static SPA build in ./dist via the ASSETS binding.
// ==============================================================================

import type { Env, RouteHandler } from "./types";

import * as health from "./routes/health";
import * as scanWebsite from "./routes/scan-website";
import * as generateVisualCreative from "./routes/generate-visual-creative";
import * as generateVideoScript from "./routes/generate-video-script";
import * as generateIntelligence from "./routes/generate-intelligence";
import * as generateTextCreative from "./routes/generate-text-creative";
import * as generateReport from "./routes/generate-report";
import * as optimizeBudget from "./routes/optimize-budget";
import * as cloudflareConfig from "./routes/cloudflare/config";
import * as cloudflareDeployTrigger from "./routes/cloudflare/deploy-trigger";
import * as paypalCapture from "./routes/billing/paypal/capture";
import * as paypalCreateSubscription from "./routes/billing/paypal/create-subscription";
import * as paytmInitiate from "./routes/billing/paytm/initiate";
import * as paytmCallback from "./routes/billing/paytm/callback";
import * as agencyResolveTheme from "./routes/agency/resolve-theme";
import * as agencyBrandingUpdate from "./routes/agency/branding/update";
import * as agencyDomainVerify from "./routes/agency/domain/verify";

interface Route {
  method: "GET" | "POST";
  pattern: string; // exact pathname match, e.g. "/api/health"
  handler: RouteHandler;
}

// Route table — mirrors the original functions/api/** file-based paths 1:1,
// so every existing `fetch('/api/...')` call in src/ keeps working unchanged.
const routes: Route[] = [
  { method: "GET", pattern: "/api/health", handler: health.onGet },
  { method: "POST", pattern: "/api/scan-website", handler: scanWebsite.onPost },
  { method: "POST", pattern: "/api/generate-visual-creative", handler: generateVisualCreative.onPost },
  { method: "POST", pattern: "/api/generate-video-script", handler: generateVideoScript.onPost },
  { method: "POST", pattern: "/api/generate-intelligence", handler: generateIntelligence.onPost },
  { method: "POST", pattern: "/api/generate-text-creative", handler: generateTextCreative.onPost },
  { method: "POST", pattern: "/api/generate-report", handler: generateReport.onPost },
  { method: "POST", pattern: "/api/optimize-budget", handler: optimizeBudget.onPost },
  { method: "GET", pattern: "/api/cloudflare/config", handler: cloudflareConfig.onGet },
  { method: "POST", pattern: "/api/cloudflare/deploy-trigger", handler: cloudflareDeployTrigger.onPost },
  { method: "POST", pattern: "/api/billing/paypal/capture", handler: paypalCapture.onPost },
  { method: "POST", pattern: "/api/billing/paypal/create-subscription", handler: paypalCreateSubscription.onPost },
  { method: "POST", pattern: "/api/billing/paytm/initiate", handler: paytmInitiate.onPost },
  { method: "POST", pattern: "/api/billing/paytm/callback", handler: paytmCallback.onPost },
  { method: "GET", pattern: "/api/agency/resolve-theme", handler: agencyResolveTheme.onGet },
  { method: "POST", pattern: "/api/agency/branding/update", handler: agencyBrandingUpdate.onPost },
  { method: "POST", pattern: "/api/agency/domain/verify", handler: agencyDomainVerify.onPost },
];

function withCors(response: Response): Response {
  const headers = new Headers(response.headers);
  headers.set("Access-Control-Allow-Origin", "*");
  headers.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  return new Response(response.body, { status: response.status, headers });
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === "OPTIONS" && url.pathname.startsWith("/api/")) {
      return withCors(new Response(null, { status: 204 }));
    }

    if (url.pathname.startsWith("/api/")) {
      const route = routes.find(
        (r) => r.pattern === url.pathname && r.method === request.method
      );

      if (!route) {
        return withCors(
          Response.json({ error: `No API route for ${request.method} ${url.pathname}` }, { status: 404 })
        );
      }

      try {
        const response = await route.handler(request, env, ctx);
        return withCors(response);
      } catch (err: any) {
        return withCors(Response.json({ error: err?.message || "Internal Worker error" }, { status: 500 }));
      }
    }

    // Everything else is the static Vite SPA build, served via the Workers
    // "assets" binding (configured in wrangler.jsonc / wrangler.toml).
    return env.ASSETS.fetch(request);
  },
};
