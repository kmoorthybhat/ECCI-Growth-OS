import type { RouteHandler } from "../types";

export const onGet: RouteHandler = async () => {
  return Response.json({ status: "ok", service: "ECCI Growth OS v1.0 API Engine" });
};
