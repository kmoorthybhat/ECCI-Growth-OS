import type { RouteHandler } from "../../types";

export const onGet: RouteHandler = async () => {
  return Response.json({
    projectName: "ecci-growth-os",
    frameworkPreset: "Vite + React (Cloudflare Worker)",
    buildCommand: "npm run build",
    buildOutputDirectory: "dist",
    workerEntry: "worker/index.ts",
    nodeVersion: "20.10.0",
    rootDirectory: "/",
    deploymentUrl: "https://ecci-growth-os.workers.dev",
    compatibilityDate: "2024-09-23",
    compatibilityFlags: ["nodejs_compat"],
    kvNamespaces: [
      { binding: "CACHE", id: "<YOUR_CLOUDFLARE_KV_NAMESPACE_ID>" },
      { binding: "SESSIONS", id: "<YOUR_SESSION_KV_NAMESPACE_ID>" },
    ],
  });
};
