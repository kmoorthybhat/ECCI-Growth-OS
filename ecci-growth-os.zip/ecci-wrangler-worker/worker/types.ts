// ==============================================================================
// ECCI Growth OS — Cloudflare Worker Environment Bindings
// ==============================================================================
// This is the single source of truth for everything injected into the Worker
// at runtime by Wrangler (vars, secrets, KV, D1, R2, Queues, Durable Objects,
// Vectorize, Workers AI, Browser Rendering, Analytics Engine, Hyperdrive).
// Keep this in sync with wrangler.jsonc / wrangler.toml.
// ==============================================================================

export interface Env {
  // Static assets binding (serves the built Vite SPA from ./dist)
  ASSETS: Fetcher;

  // Non-secret vars (see wrangler.jsonc "vars")
  APP_NAME: string;
  COMPANY_NAME: string;
  APP_ENV: string;
  APP_VERSION: string;
  NODE_ENV: string;
  API_VERSION: string;
  DEFAULT_LOCALE: string;
  DEFAULT_TIMEZONE: string;
  ENABLE_ANALYTICS: string;
  ENABLE_AI: string;
  ENABLE_EMAILS: string;
  ENABLE_SOCIAL_AUTOMATION: string;
  ENABLE_BUILDER_PANEL: string;
  ENABLE_CAMPAIGNS: string;
  ENABLE_VECTOR_SEARCH: string;
  ENABLE_WORKFLOWS: string;

  // Secrets (provision via `wrangler secret put <NAME>`)
  GEMINI_API_KEY?: string;
  OPENAI_API_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  META_APP_SECRET?: string;
  META_ACCESS_TOKEN?: string;
  GOOGLE_CLIENT_SECRET?: string;
  GOOGLE_API_KEY?: string;
  GOOGLE_MAPS_KEY?: string;
  RESEND_API_KEY?: string;
  SENDGRID_API_KEY?: string;
  MAILGUN_API_KEY?: string;
  STRIPE_SECRET_KEY?: string;
  PAYPAL_CLIENT_SECRET?: string;
  CLOUDFLARE_API_TOKEN?: string;
  JWT_SECRET?: string;
  ENCRYPTION_KEY?: string;
  WEBHOOK_SECRET?: string;
  SUPABASE_SERVICE_ROLE_KEY?: string;
  NOTION_API_KEY?: string;
  SLACK_BOT_TOKEN?: string;
  PAYTM_MID?: string;

  // D1
  DB: D1Database;

  // KV
  CACHE: KVNamespace;
  SESSIONS: KVNamespace;
  CONFIG: KVNamespace;

  // R2 (renamed from "ASSETS" to "MEDIA_BUCKET" to avoid clashing with the
  // static-assets binding, which must be named "ASSETS" for Wrangler assets)
  MEDIA_BUCKET: R2Bucket;
  REPORTS: R2Bucket;

  // Queues
  BACKGROUND_QUEUE: Queue;

  // Durable Objects
  AI_AGENT: DurableObjectNamespace;
  WORKFLOW_ENGINE: DurableObjectNamespace;

  // Vectorize
  VECTOR_INDEX: VectorizeIndex;

  // Workers AI
  AI: Ai;

  // Browser Rendering
  BROWSER: Fetcher;

  // Analytics Engine
  ANALYTICS: AnalyticsEngineDataset;

  // Hyperdrive
  HYPERDRIVE: Hyperdrive;
}

/** Shared signature every route handler in worker/routes/** implements. */
export type RouteHandler = (
  request: Request,
  env: Env,
  ctx: ExecutionContext
) => Promise<Response> | Response;

/** Calls the Gemini generateContent REST API and returns the raw text output. */
export async function generateGeminiContent(
  apiKey: string,
  model: string,
  prompt: string
): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
    }),
  });
  if (!response.ok) {
    throw new Error(`Gemini API error ${response.status}: ${await response.text()}`);
  }
  const data = (await response.json()) as any;
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}
