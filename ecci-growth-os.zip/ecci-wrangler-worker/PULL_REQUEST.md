## 🚀 Conversion PR: Pages Functions/OpenNext → Pure Cloudflare Worker (Wrangler syntax)

### Overview
This PR converts **ECCI Growth OS** from a Cloudflare Pages Functions app
(file-based `functions/api/**/onRequestGet|onRequestPost` handlers, with
leftover Next.js/OpenNext scaffolding that didn't match the actual Vite/React
codebase) into a single, pure Cloudflare **Worker** written in standard
Wrangler module syntax.

### Detected Settings (corrected)
- **Framework**: Vite + React 19 (SPA) — *not* Next.js; the previous
  `main: ".open-next/worker.js"` entry and OpenNext build scripts never
  matched this project and have been removed.
- **Build Command**: `vite build` → outputs static assets to `dist/`
- **Worker Entry**: `worker/index.ts` (`export default { fetch(request, env, ctx) {...} }`)
- **Deploy Command**: `npm run build && wrangler deploy`
- **Worker Target Name**: `ecci-growth-os`

### Included Changes
1. **`worker/index.ts` + `worker/routes/**`**: All 17 API endpoints
   previously implemented as separate Pages Functions files are now plain
   handler functions imported into one router, matching pure Wrangler
   module-Worker syntax. Route paths are unchanged (`/api/health`,
   `/api/billing/paypal/capture`, etc.), so the frontend needed no changes.
2. **`worker/types.ts`**: Centralized, typed `Env` interface for every
   binding (D1, KV, R2, Queues, Durable Objects, Vectorize, Workers AI,
   Browser Rendering, Analytics, Hyperdrive) plus the shared Gemini API
   helper used by several routes.
3. **`wrangler.jsonc` / `wrangler.toml`**: `main` now points to
   `worker/index.ts`; `assets.directory` points to `dist` with
   `not_found_handling: "single-page-application"` for SPA routing. Fixed a
   binding name collision — the R2 media bucket was named `ASSETS`, clashing
   with the required static-assets binding name; renamed to `MEDIA_BUCKET`.
4. **`package.json`**: Replaced Express/OpenNext/next-on-pages scripts and
   dependencies with `wrangler dev` / `vite build && wrangler deploy`.
5. **`tsconfig.json`**: Added `@cloudflare/workers-types` so `worker/**`
   type-checks against `D1Database`, `KVNamespace`, `ExecutionContext`, etc.
6. **Removed**: `functions/` (old Pages Functions), `server.ts` (Express dev
   server) — both fully superseded by `worker/index.ts` + `wrangler dev`.

### Verification Steps
- [ ] `npm install && npm run build` completes with `dist/index.html` present.
- [ ] `npm run dev` (wrangler dev) serves the app and all `/api/*` routes
      respond correctly — see `TESTING.md` for the full endpoint checklist.
- [ ] `wrangler deploy --dry-run` bundles `worker/index.ts` with no errors.
- [ ] Replace `<YOUR_*_ID>` placeholders in `wrangler.jsonc`/`wrangler.toml`
      with real D1/KV/R2/Hyperdrive resource IDs before deploying to production.
- [ ] Set required secrets via `wrangler secret put <NAME>` (see the list of
      expected secrets commented in `wrangler.jsonc`).
- [ ] **Merge PR**: enables single-artifact Worker deployments going forward.
